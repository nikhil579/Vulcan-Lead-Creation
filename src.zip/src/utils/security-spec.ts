export const OPERATION_SECURITY_SPEC = [{jwt: []}];
// export const SECURITY_SCHEME_SPEC =
//   [{
//     "bearerAuth": {
//       "type": "http",
//       "scheme": "bearer",
//       "bearerFormat": "JWT"
//     }
//   }];
